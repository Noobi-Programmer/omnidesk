# Decision Ledger

Status legend: **VERIFIED** (cited source), **DECISION** (our call, reasoned),
**ASSUMPTION** (unverified — to check before relying on it), **REJECTED** (considered, declined).

| # | Decision | Status | Rationale / Source |
| --- | --- | --- | --- |
| D-01 | Use official `@tiny-fish/sdk` (v0.11.0, npm 2026-10-28) for all TinyFish calls | VERIFIED | docs: "Always use the official SDKs"; registry.npmjs.org/@tiny-fish/sdk |
| D-02 | Cost ladder Search→Fetch→Agent→Browser; Agent only on escalation | VERIFIED pattern | docs.tinyfish.ai/for-coding-agents.md + cookbook use-tinyfish SKILL.md |
| D-03 | Search & Fetch are free-tier (search ≤12k req/day, 30 RPM; fetch 1k URLs/day, 150/min) | VERIFIED | docs.tinyfish.ai/search-api, /fetch-api, tinyfish.ai/pricing |
| D-04 | Agent = $0.016/step, 2 concurrent; Browser = $0.002/min, 5 sessions; new accounts get $8 wallet | VERIFIED | tinyfish.ai/pricing |
| D-05 | Use Agent `/run-sse` only (cancellable, progress, `STREAMING_URL`); never `/run` (uncancellable) | VERIFIED | docs.tinyfish.ai/key-concepts/endpoints |
| D-06 | Bound agent runs with `max_duration_seconds: 120` (not `max_steps`, which is beta-gated) | VERIFIED | endpoints docs mark `max_steps` beta |
| D-07 | TinyFish Research API NOT used in demo (5–20 min latency; $2/$3 per run after 2 free/day; 403 unless enabled) — future "Deep Report" only | VERIFIED + DECISION | docs.tinyfish.ai/research-api/reference |
| D-08 | Datasets API rejected for MVP (beta: 3 runs/rolling 24h) | VERIFIED + REJECTED | mcp-integration rates + datasets notes |
| D-09 | Supplier URLs come from real Search results, never LLM-generated (hallucination control) | VERIFIED pattern | cookbook lego-hunter ("No OpenAI for URL generation") |
| D-10 | One Agent run per site, parallel via `Promise.allSettled`; never multi-site goals | VERIFIED pattern | cookbook SKILL.md + openbox-deals |
| D-11 | Product LLM = Gemini API free tier behind a provider-agnostic `LLMProvider` | VERIFIED free tier exists + DECISION | ai.google.dev/gemini-api/docs/rate-limits (Free tier, RPM/TPM/RPD; page updated 2026-10-28). Exact per-model RPM/RPD: check AI Studio before M1. Groq free tier = fallback, current limits **TO VERIFY** |
| D-12 | Web-chat subscriptions (Claude/GPT/Gemini web) are dev assistants, never product inference | DECISION | user constraint + correctness |
| D-13 | No database in MVP; localStorage `HistoryStore`; Supabase schema reserved (DATABASE_SCHEMA.md) | DECISION | cookbook no-DB pattern; ₹0; time budget |
| D-14 | No auth in MVP (single demo user) | DECISION | scope discipline |
| D-15 | Approvals produce mailto/clipboard only; server cannot send anything; no payments anywhere | DECISION | trust model; hackathon scope |
| D-16 | Build order P0→P1 with P2/P3 as conditional stretches, preferring P3 (agent form-fill) over P2 (Gmail OAuth) when time-limited | DECISION | P3 is ~30–40 min vs P2's 60–90 min OAuth/review risk; swap reasoned in chat handoff |
| D-17 | SSE from `POST /api/research` (single route) rather than task+polling | DECISION | cookbook-proven (openbox-deals, competitor-analysis); no background infra on Vercel Hobby |
| D-18 | Repo `Noobi-Programmer/omnidesk` does not exist yet — create via `gh repo create` (setup/GITHUB_SETUP.md) | VERIFIED (404 on 2026-11-01) | github.com/Noobi-Programmer/omnidesk |
| D-19 | Gmail API read-only is the only feasible P2 inbox stretch; Meta (WhatsApp/IG) APIs need app review — verify limits before any P2 code | ASSUMPTION (to verify) | developer docs to check: developers.google.com/gmail/api, developers.facebook.com — not yet opened this session |
| D-20 | pnpm + Next.js (App Router) + TS strict + Tailwind; Vercel Hobby deploy | DECISION | free tier; matches cookbook reference projects |
| D-21 | TinyFish MCP/plugins for our *dev* agents (OpenCode etc.); product uses REST SDK only | VERIFIED + DECISION | docs.tinyfish.ai/mcp-integration |
| D-22 | Prompt-injection defence: fencing + extraction-only prompts + zod schemas + human gate | DECISION | layered defence in SECURITY_AND_APPROVALS.md |

Change protocol: any new architectural decision gets a row here (status + one-line rationale)
before code is written against it. Disagreements between agents resolve in this file, not in PRs.
