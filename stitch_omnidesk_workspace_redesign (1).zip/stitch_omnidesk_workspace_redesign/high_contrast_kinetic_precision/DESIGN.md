---
name: High-Contrast Kinetic Precision
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#e3bfb1'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#aa8a7d'
  outline-variant: '#5a4136'
  surface-tint: '#ffb596'
  primary: '#ffb596'
  on-primary: '#581e00'
  primary-container: '#ff6600'
  on-primary-container: '#561d00'
  inverse-primary: '#a33e00'
  secondary: '#ffb690'
  on-secondary: '#552100'
  secondary-container: '#ec6a06'
  on-secondary-container: '#4a1c00'
  tertiary: '#9ccaff'
  on-tertiary: '#003256'
  tertiary-container: '#009cfc'
  on-tertiary-container: '#003155'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7c2e00'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb690'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#783200'
  tertiary-fixed: '#d0e4ff'
  tertiary-fixed-dim: '#9ccaff'
  on-tertiary-fixed: '#001d35'
  on-tertiary-fixed-variant: '#00497b'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-hero:
    fontFamily: Geist
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  code-data:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an unapologetic, high-performance aesthetic rooted in absolute clarity, architectural minimalism, and uncompromising contrast. It borrows the discipline of Swiss international typography and merges it with technical, high-density dashboard instrumentation.

### Target Audience & Emotional Response
Engineers, quantitative analysts, system architects, and executive operators who demand signal over noise. The interface elicits an immediate sense of speed, precision, structural integrity, and absolute decisiveness. There is zero decorative fluff—every pixel serves functional orientation or data revelation.

### Visual Style
- **Aesthetic Movement:** Precision High-Contrast Technical Minimalist.
- **Core Elements:** Absolute binary baseline (pitch black `#000000` against pristine white `#FFFFFF`), 1px structural framing, razor-sharp typography, and explosive kinetic energy delivered exclusively via hyper-saturated classic orange accents.
- **Tone:** Authoritative, uncompromising, razor-sharp, zero-latency.

## Colors

The palette rejects mid-tone gray muddiness entirely. Visual architecture is created through absolute binary opposites combined with a hyper-vibrant industrial orange accent.

### Palette Architecture
- **Primary Accent (`#FF6600` / `#F97316`):** Reserved exclusively for focal execution—primary action triggers, active tabs, real-time telemetry sparklines, selection states, and live alerts. It must never be diluted or applied across large background fills.
- **Dark Mode (Default):** Canvas rests on pure pitch black (`#000000`). Nested surfaces use strict 1px boundary lines (`#262626` resting, `#404040` hover, `#FF6600` active) with deep interior planes (`#0A0A0A` and `#121212`). Text defaults to absolute crisp white (`#FFFFFF`) with secondary metadata rendered in high-legibility crisp light silver (`#A3A3A3`).
- **Light Mode:** Canvas rests on unadulterated pure white (`#FFFFFF`). Structural delineation is managed via `#000000` text/borders or crisp structural dividers (`#E5E5E5`). 
- **Purity Rule:** Avoid warm grays or tinted mid-tones. All supporting tones belong strictly to the neutral monochrome ramp to maintain total mechanical purity.

## Typography

The typographic hierarchy couples **Geist** for tight, neutral, geometric interface execution with **JetBrains Mono** for data density, telemetry, labels, and badges.

### Typographic Principles
- **Weight Restraint:** Limit weights to Regular (`400`), Medium (`500`), and SemiBold (`600`). Heavy or black weights are barred to prevent visual bloat and keep line rhythms razor-sharp.
- **Negative Tracking:** All display and headline tiers require negative letter-spacing to build solid, architectural word-forms.
- **Data & Metric Display:** Numerical values, statistics, micro-tags, timestamps, and status markers default to `JetBrains Mono` with uppercase transformations to anchor tabular information precisely.

## Layout & Spacing

Layouts follow an obsessive structural grid aligned to a 4px/8px incremental base coordinate system.

### Grid & Composition
- **Desktop (12 Columns):** Fluid structural layout bounded at a max width of 1440px, configured with `1.5rem` (24px) gutters and `3rem` (48px) margins. Columns act as technical coordinate zones with hairline grid lines demarcating key panels.
- **Tablet (8 Columns):** Standardized across breakpoints (768px - 1024px) with `1rem` (16px) gutters and `2rem` (32px) margins. Side rails collapse into sliding side drawers or top navigation bars.
- **Mobile (4 Columns):** Strict 4-column flow with `1rem` (16px) margins and gutters. Multi-column metric groups collapse into vertically stacked 1px-bordered cells.

### Spacing Philosophy
Negative space is treated with architectural discipline. Component interiors maintain compact padding (`space-xs` to `space-md`) to ensure high information density, while layout canvas divisions leverage generous margins (`space-xl`) to establish authoritative section boundaries.

## Elevation & Depth

This system strictly rejects diffuse, blurry drop shadows, colored skeuomorphic glows, and decorative translucent glass. Elevation is conveyed strictly through structural 1px borders and distinct surface luminosity planes.

### Depth Modalities
- **Level 0 (Base Canvas):** Pitch black `#000000` (dark mode) or pristine white `#FFFFFF` (light mode).
- **Level 1 (Card & Module Surfaces):** Dark mode `#0A0A0A` bounded by a crisp 1px `#262626` outline.
- **Level 2 (Popovers, Flyouts, Menus):** Dark mode `#121212` enclosed within a 1px `#404040` border.
- **Level 3 (Modal Dialogs & Overlays):** Dark mode `#171717` framed by a dual-edge outline: 1px `#525252` outer perimeter with a hard, zero-blur structural offset shadow `0 0 0 1px #000000, 0 16px 32px -8px rgba(0, 0, 0, 0.9)`.
- **Active / Accent Border Focus:** Elevated interactive items highlight by transitioning their perimeter border from neutral boundary gray (`#262626`) directly to high-visibility orange (`#FF6600`).

## Shapes

The design uses an ultra-tight, machined corner radius (`roundedness: 1`). 

### Radius Architecture
- **Micro & Standard Controls (Buttons, Inputs, Badges, Tabs):** `0.25rem` (4px). Offers precise, technical cornering without the severe aggression of pure 0px edges or the consumer softness of rounded pills.
- **Structural Containers (Cards, Modals, Drawers):** `0.5rem` (8px). Maintains frame structure while keeping the interface disciplined and industrial.
- **Geometric Elements (Sparkline points, Status pips):** Pure circles (`50%`) are used strictly for live status indicators, counter dots, and chart nodes to distinguish data anchors from interactive containers.

## Components

### Buttons
- **Primary:** Background `#FF6600`, text `#000000`, font `Geist Medium 14px`, 4px radius. Hover shifts to `#F97316`. Active state scales down `0.98` with high-contrast text stability.
- **Secondary / Outline:** Background `#000000`, border 1px solid `#404040`, text `#FFFFFF`. Hover transitions border to `#FFFFFF` and background to `#121212`.
- **Ghost:** Background transparent, text `#A3A3A3`. Hover transitions text to `#FF6600`.

### Chips & Badges
- **Status Badges:** JetBrains Mono 10px uppercase, tracking `0.06em`. 1px solid `#262626` border, background `#0A0A0A`. Includes a 6px circular pip: live systems show `#FF6600` with pulse; inactive show `#525252`.
- **Filter Chips:** 4px radius, 1px solid `#262626`. Selected state switches border to `#FF6600`, text to `#FFFFFF`, with an inner indicator dash in `#FF6600`.

### Input Fields
- **Base State:** Background `#0A0A0A`, border 1px solid `#262626`, text `#FFFFFF`, font `Geist 14px`, placeholder `#525252`.
- **Focus State:** Border shifts instantaneously to 1px `#FF6600`. Zero diffuse focus rings; only a crisp hairline line-weight transformation.
- **Error State:** Border shifts to pure high-contrast red-orange (`#EF4444`) with monospaced helper text below.

### Cards & Panels
- **Structure:** Background `#0A0A0A`, 1px solid perimeter `#262626`, 8px radius.
- **Header Dividers:** Section headers inside cards terminate with a full-bleed 1px horizontal rule `#1C1C1C`.
- **Interactive Cards:** Hover shifts the entire 1px border to `#404040`, revealing an accent top edge or corner marker in `#FF6600`.

### Lists & Tables
- **Table Cells:** Height 44px, border-bottom 1px solid `#1C1C1C`. Alternating row striping is prohibited; row hover shifts background to `#121212`.
- **Metrics / Data Display:** Formatted with `JetBrains Mono`. Changes over time leverage `#FF6600` for active alerts and sparklines.

### Checkboxes & Radios
- **Checkbox:** 16px square, 2px radius, 1px solid `#404040`, background `#000000`. Checked state renders full `#FF6600` background with a pitch black `#000000` vector checkmark.
- **Radio:** 16px circular boundary, 1px solid `#404040`. Selected state centers a 6px solid `#FF6600` dot.

### Specialized Telemetry: Sparklines
- **Graphic Style:** Ultra-thin 1.5px vector path rendered in `#FF6600` over a pitch-black canvas. Area fill beneath uses a gradient strictly from `rgba(255, 102, 0, 0.12)` fading to transparent at the baseline.