---
name: Kinetic Mono
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#5a4136'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#8e7164'
  outline-variant: '#e3bfb1'
  surface-tint: '#a33e00'
  primary: '#a33e00'
  on-primary: '#ffffff'
  primary-container: '#ff6600'
  on-primary-container: '#561d00'
  inverse-primary: '#ffb596'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e2'
  on-secondary-container: '#646464'
  tertiary: '#0062a1'
  on-tertiary: '#ffffff'
  tertiary-container: '#009cfc'
  on-tertiary-container: '#003155'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7c2e00'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#d0e4ff'
  tertiary-fixed-dim: '#9ccaff'
  on-tertiary-fixed: '#001d35'
  on-tertiary-fixed-variant: '#00497b'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e3e2e2'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 3.75rem
    letterSpacing: -0.04em
  display-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.125rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Geist
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 2rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system expresses high-precision utility, razor-sharp editorial restraint, and kinetic energy. Designed for high-performance developer tools, analytical dashboards, and modern fintech products, the aesthetic fuses gallery-grade Swiss minimalism with functional engineering precision.

The visual narrative hinges on stark juxtaposition: absolute monochrome stillness disrupted by surgical strikes of high-visibility safety orange. Interaction surfaces evoke industrial instrument panels stripped of all decorative baggage. Every layout element exists solely to frame information with extreme density and legibility.

Key stylistic pillars:
- **Absolute Contrast:** Deep pitch black typography against pristine pure white ground, bypassing soft charcoal compromises.
- **Architectural Framing:** Structural grid boundaries created via hairline dividers rather than elevated drop shadows.
- **Controlled Kinetic Accent:** Orange is deployed strictly as an intentional signal—never decorative backdrop—signaling active state, immediate action, or dynamic telemetry.

## Colors

The palette operates under an uncompromising monochrome discipline punctured by an intentional chromatic flash:

- **Primary (`#FF6600`):** Classic industrial orange. Reserved exclusively for actionable primaries, active tabs, micro-status indicators, live telemetry graphs, and critical focus rings.
- **Secondary / Ink (`#000000`):** Pitch black. Drives all standard display text, primary iconography, solid inverse interactive surfaces, and focused states.
- **Background Layer (`#FFFFFF`):** Pure light emitter canvas. Zero tinting, ensuring uncompromising sharpness.
- **Surface Layer (`#F8F9FA`):** Technical low-contrast ground for secondary modules, code blocks, table row alternate fills, and recessed wells.
- **Structural Border (`#E5E5E5`):** Hairline 1px separation tokens across all cards, divider axes, and interface modules.
- **Subtle Border (`#F0F0F0`):** Internal cell boundaries and non-critical nested divisions.
- **Muted Neutral (`#737373`):** Secondary metadata, inactive states, placeholder tokens, and tertiary navigational links.

## Typography

The typographic hierarchy implements three distinct operational roles:

1. **Hanken Grotesk:** Anchors the architectural framing across all headlines and display roles. Its geometric sharpness and tight tracking establish executive authority.
2. **Geist:** Handles dense prose, descriptive content, and multi-line body layouts with neutral utilitarian clarity.
3. **JetBrains Mono:** Governs labels, tags, tabular numbers, status readouts, sparkline metric tooltips, and component captions. Rendered with uppercase styling or tracked micro-metrics to evoke calibrated hardware readouts.

Rules for implementation:
- Display headings must enforce negative letter-spacing to maintain optical density.
- Numeric metrics and data figures must always leverage monospace alignment (`font-variant-numeric: tabular-nums`).
- Running copy limits width to a strict 65-character measure to retain ergonomic scanning against raw `#FFFFFF` surfaces.

## Layout & Spacing

The structural layout utilizes a strict 12-column grid bound by mathematical cadence based on a 4px baseline unit.

- **Breakpoints:**
  - Mobile: `< 768px` (4 columns, `margin`: 1rem, `gutter`: 1rem)
  - Tablet: `768px - 1199px` (8 columns, `margin-md`: 2rem, `gutter-md`: 1.5rem)
  - Desktop: `≥ 1200px` (12 columns, `margin-lg`: 3rem, `gutter-lg`: 2rem, max layout container `1440px`)

Layout modules are abutted directly against structural 1px border intersections, prioritizing structured pane layouts over floating card arrangements. Generous internal padding within components offsets dense typographic arrangements, preventing visual exhaustion.

## Elevation & Depth

This system rejects ambient drop shadows, blurred glow layers, and tinted skeuomorphic depths. Elevation is rendered entirely through **Tonal Stratification and Low-Contrast Hairline Borders**:

- **Ground Level (Base Canvas):** Pure `#FFFFFF`.
- **Level 1 (Panels, Nav Rails, Data Cards):** Pure `#FFFFFF` framed by a 1px solid `#E5E5E5` perimeter border.
- **Level 2 (In-set Cells, Sub-panels, Table Headers):** Flat `#F8F9FA` fill with interior `#E5E5E5` hairline dividers.
- **Level 3 (Overlays, Flyouts, Popovers):** Solid `#FFFFFF` enclosed in a high-definition composite border: `1px solid #000000`, anchored by an intentional zero-blur offset structural drop: `box-shadow: 4px 4px 0px 0px #000000`.
- **Level 4 (Modals):** Pure `#FFFFFF` surface bordered with 1px `#000000`, displayed above a translucent blocking scrim (`rgba(0, 0, 0, 0.45)` with `backdrop-filter: blur(2px)`).

## Shapes

The geometric vernacular employs controlled, subtle corner radii (`roundedness: 1`). Elements do not use playful circular pills or sharp brutalist zero-radii; instead, corners exhibit a precise 4px (`0.25rem`) corner rounding that preserves technical rigor while preventing harsh optical corner clipping.

- **Standard Elements (Buttons, Inputs, Badges, Tabs):** `0.25rem` (4px).
- **Enclosures (Cards, Modals, Flyout Panels):** `0.5rem` (8px).
- **Indicators & Pips (Status dots, radio selectors):** Fully circular (`9999px`).

## Components

### Buttons
- **Primary:** Solid `#FF6600` background, pure `#FFFFFF` bold text, 0 border, 4px border-radius. On hover: `#E05A00`. On active/pressed: `#CC5200`. Focused with a 2px offset outline in `#000000`.
- **Secondary:** Pure `#FFFFFF` surface, 1px solid `#000000` border, `#000000` text. On hover: solid `#000000` background with `#FFFFFF` text.
- **Tertiary / Ghost:** Transparent background, `#000000` text. On hover: `#F8F9FA` fill.
- **Destructive:** Pure `#FFFFFF` surface, 1px solid `#DC2626`, text `#DC2626`. On hover: solid `#DC2626` with pure `#FFFFFF` text.

### Chips & Badges
- **Status Badges:** JetBrains Mono uppercase (`label-sm`). Rendered with `#F8F9FA` background, 1px solid `#E5E5E5` border, and `#000000` text.
- **Active Signal Badges:** Pure `#FFFFFF` background, 1px solid `#FF6600` border, `#FF6600` text, flanked by a 6px solid `#FF6600` circular pulse dot.

### Form Inputs
- **Text Inputs:** Height 40px, pure `#FFFFFF` background, 1px solid `#E5E5E5`, font `Geist` (`body-md`), text `#000000`. Placeholder set to `#737373`.
- **Focus State:** 1px solid `#000000` accompanied by a distinct 1px hairline ring (`outline: 1px solid #FF6600`).
- **Error State:** 1px solid `#DC2626`, accompanied by micro-caption in JetBrains Mono.

### Checkboxes & Radios
- **Checkboxes:** 16x16px, 2px radius, pure `#FFFFFF` fill, 1px solid `#000000`. Selected state: solid `#000000` fill with a pure `#FFFFFF` hairline tick icon.
- **Radios:** 16x16px circular housing, 1px solid `#000000`. Selected state: pure white interior with a 6px centered solid `#FF6600` inner disk.

### Cards & Module Panes
- Pure `#FFFFFF` surface bound by a uniform 1px solid `#E5E5E5` border.
- Optional header section with `#F8F9FA` background, segregated by a 1px solid bottom divider (`#E5E5E5`), containing monospace metric metadata and category tags.

### Sparklines & Telemetry Visualizations
- Background: `#FFFFFF` or `#F8F9FA`.
- Chart Grid Lines: Hairline 1px `#F0F0F0` horizontal axis ticks.
- Dynamic Trace Line: 2px solid `#FF6600` path stroke with zero shadow or area gradient fill.
- Interactive Hover Scrubber: 1px vertical hairline `#000000` guide displaying an inverted tooltip (black background, monospace white text).